package finchApp;

import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class TestColorPicker extends TestUI implements ChangeListener, WindowListener 
{

	private static final long serialVersionUID = 927L;

	
	public TestColorPicker()
	{
		setTitle("Finch LED Color Picker");
		setSize(400,400);
		super.removeAll();
		
	}
	
	
	
	@Override
	public void windowActivated(WindowEvent arg0) 
	{
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) 
	{

		
	}

	@Override
	public void windowClosing(WindowEvent arg0) 
	{
		
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) 
	{
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) 
	{
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) 
	{
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) 
	{

		
	}

	@Override
	public void stateChanged(ChangeEvent arg0) 
	{
		
	}

}
